﻿namespace ToolBoxOpdracht1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.plek7 = new System.Windows.Forms.Button();
            this.plek8 = new System.Windows.Forms.Button();
            this.plek9 = new System.Windows.Forms.Button();
            this.plek6 = new System.Windows.Forms.Button();
            this.plek5 = new System.Windows.Forms.Button();
            this.plek4 = new System.Windows.Forms.Button();
            this.plek3 = new System.Windows.Forms.Button();
            this.plek2 = new System.Windows.Forms.Button();
            this.plek1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // plek7
            // 
            this.plek7.Location = new System.Drawing.Point(188, 202);
            this.plek7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek7.Name = "plek7";
            this.plek7.Size = new System.Drawing.Size(35, 28);
            this.plek7.TabIndex = 0;
            this.plek7.TabStop = false;
            this.plek7.Text = "7";
            this.plek7.UseVisualStyleBackColor = true;
            this.plek7.Click += new System.EventHandler(this.plek7X);
            // 
            // plek8
            // 
            this.plek8.Location = new System.Drawing.Point(231, 202);
            this.plek8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek8.Name = "plek8";
            this.plek8.Size = new System.Drawing.Size(35, 28);
            this.plek8.TabIndex = 1;
            this.plek8.TabStop = false;
            this.plek8.Text = "8";
            this.plek8.UseVisualStyleBackColor = true;
            this.plek8.Click += new System.EventHandler(this.plek8X);
            // 
            // plek9
            // 
            this.plek9.Location = new System.Drawing.Point(273, 202);
            this.plek9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek9.Name = "plek9";
            this.plek9.Size = new System.Drawing.Size(35, 28);
            this.plek9.TabIndex = 2;
            this.plek9.TabStop = false;
            this.plek9.Text = "9";
            this.plek9.UseVisualStyleBackColor = true;
            this.plek9.Click += new System.EventHandler(this.plek9X);
            // 
            // plek6
            // 
            this.plek6.Location = new System.Drawing.Point(273, 166);
            this.plek6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek6.Name = "plek6";
            this.plek6.Size = new System.Drawing.Size(35, 28);
            this.plek6.TabIndex = 5;
            this.plek6.TabStop = false;
            this.plek6.Text = "6";
            this.plek6.UseVisualStyleBackColor = true;
            this.plek6.Click += new System.EventHandler(this.plek6X);
            // 
            // plek5
            // 
            this.plek5.Location = new System.Drawing.Point(231, 166);
            this.plek5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek5.Name = "plek5";
            this.plek5.Size = new System.Drawing.Size(35, 28);
            this.plek5.TabIndex = 4;
            this.plek5.TabStop = false;
            this.plek5.Text = "5";
            this.plek5.UseVisualStyleBackColor = true;
            this.plek5.Click += new System.EventHandler(this.plek5X);
            // 
            // plek4
            // 
            this.plek4.Location = new System.Drawing.Point(188, 166);
            this.plek4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek4.Name = "plek4";
            this.plek4.Size = new System.Drawing.Size(35, 28);
            this.plek4.TabIndex = 3;
            this.plek4.TabStop = false;
            this.plek4.Text = "4";
            this.plek4.UseVisualStyleBackColor = true;
            this.plek4.Click += new System.EventHandler(this.plek4X);
            // 
            // plek3
            // 
            this.plek3.Location = new System.Drawing.Point(273, 130);
            this.plek3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek3.Name = "plek3";
            this.plek3.Size = new System.Drawing.Size(35, 28);
            this.plek3.TabIndex = 8;
            this.plek3.TabStop = false;
            this.plek3.Text = "3";
            this.plek3.UseVisualStyleBackColor = true;
            this.plek3.Click += new System.EventHandler(this.plek3X);
            // 
            // plek2
            // 
            this.plek2.Location = new System.Drawing.Point(231, 130);
            this.plek2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek2.Name = "plek2";
            this.plek2.Size = new System.Drawing.Size(35, 28);
            this.plek2.TabIndex = 7;
            this.plek2.TabStop = false;
            this.plek2.Text = "2";
            this.plek2.UseVisualStyleBackColor = true;
            this.plek2.Click += new System.EventHandler(this.plek2X);
            // 
            // plek1
            // 
            this.plek1.Location = new System.Drawing.Point(188, 130);
            this.plek1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plek1.Name = "plek1";
            this.plek1.Size = new System.Drawing.Size(35, 28);
            this.plek1.TabIndex = 6;
            this.plek1.TabStop = false;
            this.plek1.Text = "1";
            this.plek1.UseVisualStyleBackColor = true;
            this.plek1.Click += new System.EventHandler(this.plek1X);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 383);
            this.Controls.Add(this.plek3);
            this.Controls.Add(this.plek2);
            this.Controls.Add(this.plek1);
            this.Controls.Add(this.plek6);
            this.Controls.Add(this.plek5);
            this.Controls.Add(this.plek4);
            this.Controls.Add(this.plek9);
            this.Controls.Add(this.plek8);
            this.Controls.Add(this.plek7);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button plek7;
        private System.Windows.Forms.Button plek8;
        private System.Windows.Forms.Button plek9;
        private System.Windows.Forms.Button plek6;
        private System.Windows.Forms.Button plek5;
        private System.Windows.Forms.Button plek4;
        private System.Windows.Forms.Button plek3;
        private System.Windows.Forms.Button plek2;
        private System.Windows.Forms.Button plek1;
    }
}

