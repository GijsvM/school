﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToolBoxOpdracht1
{
    public partial class Form1 : Form
    {

        bool Speler_heeft_1 = false;
        bool Speler_heeft_2 = false;
        bool Speler_heeft_3 = false;
        bool Speler_heeft_4 = false;
        bool Speler_heeft_5 = false;
        bool Speler_heeft_6 = false;
        bool Speler_heeft_7 = false;
        bool Speler_heeft_8 = false;
        bool Speler_heeft_9 = false;

        bool AI_heeft_1 = false;
        bool AI_heeft_2 = false;
        bool AI_heeft_3 = false;
        bool AI_heeft_4 = false;
        bool AI_heeft_5 = false;
        bool AI_heeft_6 = false;
        bool AI_heeft_7 = false;
        bool AI_heeft_8 = false;
        bool AI_heeft_9 = false;
        public Form1()
        {
            InitializeComponent();
            this.Text = "Tic Tac Toe";
            


            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void plek1X(object sender, EventArgs e)
        {
            plek1.Enabled = false;
            plek1.Text = "X";
            Speler_heeft_1 = true;
            AI();
        }
        private void plek2X(object sender, EventArgs e)
        {
            plek2.Enabled = false;
            plek2.Text = "X";
            bool Speler_heeft_2 = true;
            AI();
        }
        private void plek3X(object sender, EventArgs e)
        {
            plek3.Enabled = false;
            plek3.Text = "X";
            bool Speler_heeft_3 = true;
            AI();
        }
        private void plek4X(object sender, EventArgs e)
        {
            plek4.Enabled = false;
            plek4.Text = "X";
            bool Speler_heeft_4 = true;
            AI();
        }
        private void plek5X(object sender, EventArgs e)
        {
            plek5.Enabled = false;
            plek5.Text = "X";
            bool Speler_heeft_5 = true;
            AI();
        }
        private void plek6X(object sender, EventArgs e)
        {
            plek6.Enabled = false;
            plek6.Text = "X";
            bool Speler_heeft_6 = true;
            AI();
        }
        private void plek7X(object sender, EventArgs e)
        {
            plek7.Enabled = false;
            plek7.Text = "X";
            bool Speler_heeft_7 = true;
            AI();
        }
        private void plek8X(object sender, EventArgs e)
        {
            plek8.Enabled = false;
            plek8.Text = "X";
            bool Speler_heeft_8 = true;
            AI();
        }
        private void plek9X(object sender, EventArgs e)
        {
            plek9.Enabled = false;
            plek9.Text = "X";
            bool Speler_heeft_9 = true;
            AI();
        }
        
        private void AI()
        {
            
            if (plek1.Enabled == false)
            {
                if (plek9.Enabled == true)
                { 
                    plek9.Enabled = false;
                    plek9.Text = "O";
                }
                else if(plek3.Enabled == true)
                {
                    plek3.Enabled = false;
                    plek3.Text = "O";
                }
                else if (plek7.Enabled == true)
                {
                    plek7.Enabled = false;
                    plek7.Text = "O";
                }
            }

            if (plek2.Enabled == false)
            {
                if (plek9.Enabled == true)
                {
                    plek9.Enabled = false;
                    plek9.Text = "O";
                }
                else if (plek3.Enabled == true)
                {
                    plek3.Enabled = false;
                    plek3.Text = "O";
                }
                else if (plek7.Enabled == true)
                {
                    plek7.Enabled = false;
                    plek7.Text = "O";
                }
            }


        }

}
}

